# Charge Up 3.0 Alpha 3
Android WebView with secure local asset origin via WebViewAssetLoader. Bundles Charge Up 2.4.6 UI, MapLibre GL JS, GPS controls, route prototype and charging-station logic.

**Important:** ZIP contains no `data/manifest.json` or `data/tiles/*.json`; therefore the NDW dataset is unavailable in this build. Existing app falls back to Overpass/OpenStreetMap when available. Live availability and charging prices are not integrated. Map tiles, JS libraries, Overpass and OSRM require internet access.

Use the existing GitHub Actions build workflow but change the ZIP name in `push.paths` and the unzip command to `ChargeUp-3.0-Android-alpha3.zip`.
