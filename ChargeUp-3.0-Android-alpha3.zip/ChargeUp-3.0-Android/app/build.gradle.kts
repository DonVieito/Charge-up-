plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
 namespace = "com.chargeup.navigation"
 compileSdk = 35
 defaultConfig { applicationId = "com.chargeup.navigation"; minSdk = 26; targetSdk = 35; versionCode = 3; versionName = "3.0.0-alpha3" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("androidx.webkit:webkit:1.12.1") }
