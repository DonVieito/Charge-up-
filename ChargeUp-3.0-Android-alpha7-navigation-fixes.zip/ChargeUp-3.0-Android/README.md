# Charge Up 3.0 Alpha 3
Android WebView with secure local asset origin via WebViewAssetLoader. Bundles Charge Up 2.4.6 UI, MapLibre GL JS, GPS controls, route prototype and charging-station logic.

**Important:** ZIP contains no `data/manifest.json` or `data/tiles/*.json`; therefore the NDW dataset is unavailable in this build. Existing app falls back to Overpass/OpenStreetMap when available. Live availability and charging prices are not integrated. Map tiles, JS libraries, Overpass and OSRM require internet access.

Use the existing GitHub Actions build workflow but change the ZIP name in `push.paths` and the unzip command to `ChargeUp-3.0-Android-alpha3.zip`.


Alpha 6: mobile layout for navigation panel and action buttons, smaller charger markers, thinner route line. No change to NDW fetch or GPS routing. Turn-by-turn guidance is not implemented; test only while parked or with a passenger.


## Alpha 7 - rijtestverbeteringen
- Tik op kaart via Bestemming kiezen, of houd een plek ~0,75 seconde vast om een bestemming te selecteren; bevestig met Route hierheen.
- Android Activity behoudt WebView bij schermrotatie (`configChanges`), zodat de route en GPS-watch niet opnieuw worden aangemaakt.
- Landscape-indeling met scrollbaar menu, grotere aanraakvlakken en compact routepaneel.
- Na handmatig schuiven hervat de GPS-knop het volgen; bij nieuwe route wordt volgen aangezet.
- Let op: geen volwaardige afslagbegeleiding; publieke OSRM-testserver is niet geschikt voor productie.
- APK-ondertekening is nog niet permanent geregeld; debug builds kunnen een uninstall vereisen.
