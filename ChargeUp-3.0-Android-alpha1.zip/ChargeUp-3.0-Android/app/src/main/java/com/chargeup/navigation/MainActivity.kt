package com.chargeup.navigation

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Button
import android.view.ViewGroup
import org.maplibre.android.MapLibre
import org.maplibre.android.maps.MapView
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng

class MainActivity : Activity() {
 private lateinit var mapView: MapView
 private var awake = true
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  MapLibre.getInstance(this)
  val root = FrameLayout(this)
  mapView = MapView(this)
  root.addView(mapView, FrameLayout.LayoutParams(-1, -1))
  val header = TextView(this).apply {
   text = "⚡ CHARGE UP 3.0  ·  ALPHA"
   setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(10, 27, 44)); textSize = 17f
   setPadding(24, 30, 24, 30)
  }
  root.addView(header, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
  val toggle = Button(this).apply { text = "Scherm aan: JA"; setOnClickListener { awake = !awake; keepAwake(); text = if (awake) "Scherm aan: JA" else "Scherm aan: NEE" } }
  val params = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = 48 }
  root.addView(toggle, params)
  setContentView(root)
  mapView.onCreate(savedInstanceState)
  mapView.getMapAsync { map ->
   map.setStyle("https://demotiles.maplibre.org/style.json")
   map.moveCamera(CameraUpdateFactory.newCameraPosition(CameraPosition.Builder().target(LatLng(52.04, 5.67)).zoom(12.0).build()))
  }
  keepAwake()
  if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
   requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 10)
  }
 }
 private fun keepAwake() { if (awake) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
 override fun onStart() { super.onStart(); mapView.onStart() }
 override fun onResume() { super.onResume(); mapView.onResume() }
 override fun onPause() { mapView.onPause(); super.onPause() }
 override fun onStop() { mapView.onStop(); super.onStop() }
 override fun onLowMemory() { super.onLowMemory(); mapView.onLowMemory() }
 override fun onDestroy() { mapView.onDestroy(); super.onDestroy() }
 override fun onSaveInstanceState(outState: Bundle) { super.onSaveInstanceState(outState); mapView.onSaveInstanceState(outState) }
}
