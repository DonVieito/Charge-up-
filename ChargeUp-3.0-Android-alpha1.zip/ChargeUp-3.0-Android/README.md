# Charge Up 3.0 — Android alpha 1

Dit is een **eerste native Android-project**, niet de volledige Charge Up 3.0.

## Wat werkt / wat nog niet
- Native Android-startscherm met MapLibre-kaart (internet nodig).
- Scherm wakker houden zolang de app zichtbaar is (aan/uit-knop).
- Locatietoestemming wordt gevraagd, maar **GPS-volgen is nog niet aangesloten**.
- De kaart gebruikt voorlopig de publieke MapLibre-demostijl. De gekozen 3D-optie-C-stijl, Nederlandse laadstations, routebegeleiding, achtergrondnavigatie en Android Auto ontbreken nog.
- Een binnenkomend telefoongesprek mag de app bedekken; deze alpha biedt nog geen doorlopende achtergrondnavigatie.

## APK bouwen zonder computer
1. Upload de inhoud van deze map naar een **nieuwe branch** van je GitHub-repository (niet de werkende webversie overschrijven).
2. Ga naar Actions > Build Charge Up Android APK > Run workflow.
3. Na een geslaagde build: open de workflow-run > Artifacts > ChargeUp-3.0-alpha1-APK.
4. Download het zipbestand, pak het uit op Android en installeer `app-debug.apk`.

Let op: APK is een debugbuild voor testen; niet geschikt voor Play Store. De GitHub Actions-build is nog niet uitgevoerd of geverifieerd. Bij een mislukte build: deel de foutmelding uit Actions.
